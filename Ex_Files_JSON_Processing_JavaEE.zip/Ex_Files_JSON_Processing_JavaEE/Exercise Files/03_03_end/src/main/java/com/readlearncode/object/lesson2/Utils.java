package com.readlearncode.object.lesson2;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class Utils {

    public static String ROOT = "resources";

}