package com.readlearncode.streaming.lesson5;

import javax.json.Json;
import javax.json.JsonValue;
import javax.json.stream.JsonGenerator;
import java.io.StringWriter;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class StreamingExample3 {

    public String writeJsonStreamToString() {

        // Implement logic that constructs a JSON object using the Streaming model

        return null;
    }

}