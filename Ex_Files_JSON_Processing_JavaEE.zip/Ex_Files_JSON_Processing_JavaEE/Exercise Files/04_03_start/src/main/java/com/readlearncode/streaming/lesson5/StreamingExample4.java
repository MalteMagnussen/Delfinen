package com.readlearncode.streaming.lesson5;

import javax.json.Json;
import javax.json.JsonValue;
import javax.json.stream.JsonGenerator;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class StreamingExample4 {

    public static void main(String... args) throws IOException {

        // Implement logic that write JSON data to a flat-file

    }
}


