package com.readlearncode.object.lesson3;

import javax.json.Json;
import javax.json.JsonObject;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class ObjectExample3 {


    public JsonObject buildJsonDocument() {

        // Use builders to construct the course JSON object

        return null;
    }


}