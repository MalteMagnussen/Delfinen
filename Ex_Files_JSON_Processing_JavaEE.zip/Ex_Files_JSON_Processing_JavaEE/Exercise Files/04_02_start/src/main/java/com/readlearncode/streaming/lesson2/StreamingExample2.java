package com.readlearncode.streaming.lesson2;

import javax.json.Json;
import javax.json.stream.JsonParser;
import java.io.StringReader;

import static javax.json.stream.JsonParser.Event.VALUE_NUMBER;
import static javax.json.stream.JsonParser.Event.VALUE_STRING;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class StreamingExample2 {


    public String retrieveValue(final String key_to_find, final String json) {

        // Implement logic that traverse a JSON document and retrieves
        // the value of a given key.

        return null;
    }


}